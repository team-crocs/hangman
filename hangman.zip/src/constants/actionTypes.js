/* eslint-disable import/prefer-default-export */

// export const ACTION_DESCRIPTION = "ACTION_DESCRIPTION";
export const UPDATE_LETTER = 'UPDATE_LETTER';
export const INCREMENT_FAILED_GUESSES = 'INCREMENT_FAILED_GUESSES';
export const UPDATE_DISPLAY_ANSWER = 'UPDATE_DISPLAY_ANSWER';

export const NEW_QUESTION = 'NEW_QUESTION';
export const CHECK_WIN = 'CHECK_WIN';
export const ADD_ROOM = 'ADD_ROOM'
export const LOAD_ROOMS = 'LOAD_ROOMS'
// unused
// export const RESET_GAME = 'RESET_GAME';
