# hangman
collaborative, web-socket based hangman

## Color Palette
- Primary #6002ee
  - #3d00e0
- Secondary #90ee02 (Buttons)
- font #212121
- shadow #d5d5d5